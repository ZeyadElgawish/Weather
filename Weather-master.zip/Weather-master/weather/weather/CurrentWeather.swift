//
//  CurrentWeather.swift
//  weather
// model
//  Created by Zeyad Elgawish on 5/7/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import Foundation
//import SwiftyJSON


class CurrentWeather  {
    
    
  let apiURL = "http://api.openweathermap.org/data/2.5/weather?lat=35&lon=139&appid=05578557cd40c3b209bda9d059a64956"
   var weather = Weather()
    var arrWeather = [weather]
    func GetCurrentWeather(apiURL:URL, completionHandler: (()->())?) {
            // 2. retrieve the data
            let session = URLSession(configuration: .ephemeral)
            let task = session.dataTask(with: apiURL) {
                // completion handler using trailing closure syntax
                (data, response, error) in
                var localWeather = Array<Weather>()
                print("Im in \(#file) at line \(#line)")
                if let actualError = error {
                    print("I got an error: \(actualError)")
                } else if let actualResponse = response,
                    let actualData = data,
                    let parsedData = try? JSON(data: actualData) {
                    print("I got some data: \(actualData)")
                    let theWeather = parsedData["weather"]
                    let theRealWeather = theWeather["weather"]
                    for(_, aWeather) in theRealWeather{
                        print("I got a weather info: \(aWeather)")
                        if  let theCityName =  aWeather["City_name"].string,
                            let theDate = aWeather["Date"].string,
                            let theWeatherType = aWeather["Weather_type"].string,
                            let  theCurrentTemp = aWeather["Current_temp"].double
                            
                            {
                                print(theCityName)
                                print(theDate)
                                print(theCurrentTemp)
                                print(theWeatherType)
                        }
                        self.arrWeather = localWeather
                    }
                    print("Done with Closure. \(localWeather.count) rows")
                    // If there is a completionHandler, dispatch it to the main thread
                    DispatchQueue.main.async {
                        completionHandler?()
                    }
                } // End of Closure for session.dataTask()
                // the task is created stopped. We need to start it.
                print("I'm in \(#file) at line \(#line)")
                
                print("I'm in \(#file) at line \(#line)")
                // conditional unwrap
            }
        task.resume()
        }
}
