import UIKit

class ViewController: UIViewController {
    
    
    
  
    var myModel = WeatherCollection()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       myModel.getRecent()
        //getWeathter(city: SearchBar.text!)
    }
}
