//
//  WeaetherTableViewCell.swift
//  Weather
//
//  Created by Zeyad Elgawish on 5/9/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit

class WeaetherTableViewCell: UITableViewCell {

    @IBOutlet weak var Temp: UILabel!
    @IBOutlet weak var Temp_max: UILabel!
    @IBOutlet weak var humidy: UILabel!
    @IBOutlet weak var pressure: UILabel!
    @IBOutlet weak var timeStamp: UILabel!
    @IBOutlet weak var temp_min: UILabel!
    var myModel = WeatherCollection()
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
