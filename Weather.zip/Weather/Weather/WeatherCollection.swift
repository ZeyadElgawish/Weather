//
//  WeatherCollection.swift
//  Weather
//
//  Created by Zeyad Elgawish on 5/9/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit
class WeatherCollection {
    var currentWeather : Array<weather>?
    
    func getWeather(row: Int) -> weather? {
        return currentWeather?[row]
    }
   func generaterURL(city : String) -> URL{
    print("Im in \(#file) at line \(#line) ")
    let weatherURL = URL(string: "http://api.openweathermap.org/data/2.5/forecast?q=\(city),us?&units=imperial&APPID=05578557cd40c3b209bda9d059a64956")!
    return weatherURL
    }
    
    func getWeatherDate(url: URL, completionHandler:(()->())?){
        let session = URLSession(configuration: .ephemeral)
        print("The url is \(url.absoluteString)")
            let task = session.dataTask(with: url) {
            (data, response, error) in
            var localWeather = Array<weather>()
                        print("Im in \(#file) at line \(#line) ")
            if let actualError = error {
                print("I got an error: \(actualError)")
            } else if let actualResponse = response,
                let actualData = data,
                let parsedData = try? JSON(data: actualData) {
                print("I got some data: \(actualData)")
                print(parsedData)
                let theWeather = parsedData["list"]
                //let theWeather = parsedData["main"]
                for (_, aWeather) in theWeather{
              //  print("The weather is \(aWeather)")
                    
                    
                    
                   print("Im in \(#file) at line \(#line) ")
                    if let theTemp_min = aWeather["main"]["temp_min"].double,
                       let theTemp = aWeather["main"]["temp"].double,
                       let theTemp_max = aWeather["main"]["temp_max"].double,
                       let thePressure = aWeather["main"]["pressure"].double,
                       let theHumidity = aWeather["main"]["humidity"].double,
                       let theTimeStamp = aWeather["dt_txt"].string
                       
                        {
                        
                           let zWeather = weather(temp: theTemp,pressure: thePressure,humidity: theHumidity,temp_min: theTemp_min,  temp_max: theTemp_max, timeSt: theTimeStamp)
                            localWeather.append(zWeather)
                
                }
//                /
//                        let thePressure = theWeather["pressure"].double,
//                        let theHumidity = theWeather["humidity"].double
//                     {
//                       let zWeather = weather(temp: theTemp,pressure: thePressure,humidity: theHumidity,temp_min: theTemp_min,  temp_max: theTemp_Max)
//                        localWeather.append(zWeather)
//                   }
//                //}
                print("Im in \(#file) at line \(#line) ")
                self.currentWeather = localWeather
                print("Im in \(#file) at line \(#line) ")
                }
                print("Done with closuer \(localWeather.count) rows")
                DispatchQueue.main.async { completionHandler?()}
                print("Im in \(#file) at line \(#line) ")
                }
        } // end of CH
            
            print("Im in \(#file) at line \(#line) ")
        task.resume()
            print("Im in \(#file) at line \(#line) ")
    }
    
    
    func getRecent(completionHandler: (()->())? = nil) {
        // 1. generate a URL to get the data
        let theURL = generaterURL(city: "Farmingdale")
        getWeatherDate(url: theURL, completionHandler: completionHandler)
    }
    func getWeatherCount()->Int {
        return currentWeather?.count ?? 0
    }
}
