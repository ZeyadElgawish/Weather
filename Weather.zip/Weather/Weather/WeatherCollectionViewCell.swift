//
//  WeatherCollectionViewCell.swift
//  Weather
//
//  Created by Zeyad Elgawish on 5/9/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit

class WeatherCollectionViewCell: UICollectionViewCell {
    
}
