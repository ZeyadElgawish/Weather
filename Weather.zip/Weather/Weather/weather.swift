//
//  weather.swift
//  Weather
//
//  Created by Zeyad Elgawish on 5/9/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit
class weather {
    var temp : Double
    var pressure : Double
    var humidity : Double
    var temp_min : Double
    var temp_max : Double
    var timeSt : String
   
    
    init(temp: Double,
         pressure : Double,
         humidity : Double,
         temp_min : Double,
         temp_max : Double,
         timeSt : String
         ) {
        self.temp = temp
        self.pressure = pressure
        self.humidity = humidity
        self.temp_min = temp_min
        self.temp_max = temp_max
        self.timeSt = timeSt   
    }
    
    
}
/*
 temp":67.19,"pressure":1011.08,"humidity":42,"temp_min":67.19,"temp_max":67.19,"sea_level":1011.08,"grnd_level":837.25
 */
