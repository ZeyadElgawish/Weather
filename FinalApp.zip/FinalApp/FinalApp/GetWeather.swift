//
//  GetWeather.swift
//  FinalApp
//
//  Created by Zeyad Elgawish on 5/8/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import Foundation
