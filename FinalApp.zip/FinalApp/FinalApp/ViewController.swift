//
//  ViewController.swift
//  FinalApp
//
//  Created by Zeyad Elgawish on 5/8/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet var SearchBar: UISearchBar!
    @IBOutlet var WeatherLable: UILabel!
    
    @IBOutlet var MkMap: MkMapView!
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getWeathter(city: SearchBar.text!)
    }
    @IBAction func weatherButtonTapped(sender:UIButton){
        getWeathter(city: SearchBar.text!)
    }
    func getWeathter(city: String){
        //let city = SearchBar.text
        let map = MkMap;
        let session = URLSession.shared
        let weatherURL = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=\(city),us?&units=imperial&APPID=05578557cd40c3b209bda9d059a64956")!
        let dataTask = session.dataTask(with: weatherURL) {
            (data: Data?, response: URLResponse?, error: Error?) in
            if let error = error {
                print("Error:\n\(error)")
            } else {
                if let data = data {
                    let dataString = String(data: data, encoding: String.Encoding.utf8)
                    print("All the weather data:\n\(dataString!)")
                    if let jsonObj = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSDictionary {
                        if let mainDictionary = jsonObj!.value(forKey: "main") as? NSDictionary {
                            if let temperature = mainDictionary.value(forKey: "temp"),
                                let Long =  mainDictionary.value(forKey: "lon"),
                                let lat = mainDictionary.value(forKey: "lat")
                                {
                                DispatchQueue.main.async {
                                    self.WeatherLable.text = "\(city) Temperature: \(temperature)°F"
                                   
                                    }
                            }
                        } else {
                            print("Error: unable to find temperature in dictionary")
                        }
                    } else {
                        print("Error: unable to convert json data")
                    }
                } else {
                    print("Error: did not receive data")
                }
            }
        }
        dataTask.resume()
    }

}

