//
//  ViewController.swift
//  weather
//
//  Created by Zeyad Elgawish on 5/7/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // outlet
    
    @IBOutlet weak var bg: UIImageView!
    @IBOutlet weak var WeatherType: UILabel!
    @IBOutlet weak var CityName: UILabel!
    @IBOutlet weak var WeatherTemp: UILabel!
    @IBOutlet weak var WeatherImage: UIImageView!
    @IBOutlet weak var CurrentDate: UILabel!
    //constaints
    //cariables
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
}

