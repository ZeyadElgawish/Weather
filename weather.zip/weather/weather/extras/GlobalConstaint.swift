//
//  GlobalConstaint.swift
//  weather
//
//  Created by Zeyad Elgawish on 5/7/19.
//  Copyright © 2019 Zeyad Elgawish. All rights reserved.
//

import Foundation
let apiURL="http://api.openweathermap.org/data/2.5/weather?lat=35&lon=139&appid=05578557cd40c3b209bda9d059a64956"
typealias DownloadComplete = () -> ()
